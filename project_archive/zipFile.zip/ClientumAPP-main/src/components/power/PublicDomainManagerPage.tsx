import React, { useState } from 'react';
import {
  Globe,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  RefreshCw,
  Search,
  ExternalLink,
  Lock,
  Plus,
  Trash2,
  Copy,
  FileCode,
  Download,
  Sparkles,
  Server,
  Cloud
} from 'lucide-react';
import { useCRM } from '../../context/CRMContext';

interface DnsRecord {
  id: string;
  type: 'A' | 'CNAME' | 'TXT' | 'MX';
  host: string;
  value: string;
  ttl: string;
  status: 'Propagado' | 'Pendiente' | 'Error';
  proxied?: boolean;
}

export const PublicDomainManagerPage: React.FC = () => {
  const { showToast } = useCRM();

  const [domainName, setDomainName] = useState('miempresa.com.ar');
  const [activeTab, setActiveTab] = useState<'dns' | 'ssl' | 'seo' | 'sitemap'>('dns');
  const [isVerifying, setIsVerifying] = useState(false);

  // DNS records table
  const [records, setRecords] = useState<DnsRecord[]>([
    {
      id: 'dns-1',
      type: 'A',
      host: '@',
      value: '190.228.29.112',
      ttl: 'Auto',
      status: 'Propagado',
      proxied: true
    },
    {
      id: 'dns-2',
      type: 'CNAME',
      host: 'www',
      value: 'domains.clientum.com.ar',
      ttl: 'Auto',
      status: 'Propagado',
      proxied: true
    },
    {
      id: 'dns-3',
      type: 'TXT',
      host: '@',
      value: 'v=spf1 include:_spf.clientum.com.ar ~all',
      ttl: 'Auto',
      status: 'Propagado',
      proxied: false
    },
    {
      id: 'dns-4',
      type: 'MX',
      host: '@',
      value: 'mail.clientum.com.ar (Prioridad 10)',
      ttl: 'Auto',
      status: 'Propagado',
      proxied: false
    }
  ]);

  // SEO Score diagnostic
  const seoScore = 96;
  const [seoTargetUrl, setSeoTargetUrl] = useState(`https://${domainName}`);

  const seoReport = [
    { tag: 'Meta Title & OpenGraph', status: 'ok', text: 'Presente y optimizado con palabras clave comerciales' },
    { tag: 'Meta Description', status: 'ok', text: 'Longitud ideal (156 caracteres) con llamada a la acción' },
    { tag: 'Indexabilidad Robots.txt', status: 'ok', text: 'Index, Follow activo para buscadores Google y Bing' },
    { tag: 'Etiquetado Canónico', status: 'ok', text: 'Enlace canónico auto-referenciado configurado' },
    { tag: 'Velocidad First Contentful Paint (FCP)', status: 'ok', text: '0.8s en servidores Edge CDN Patagonia / BsAs' },
    { tag: 'Estructura H1 / H2 / H3', status: 'ok', text: 'Jerarquía semántica válida sin saltos de encabezados' }
  ];

  const sitemapXmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://${domainName}/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://${domainName}/producto</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://${domainName}/precios</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://${domainName}/tienda</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
</urlset>`;

  const handleVerifyDns = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setRecords(prev =>
        prev.map(r => ({ ...r, status: 'Propagado' }))
      );
      setIsVerifying(false);
      showToast('DNS verificados en tiempo real: Todos los registros propagados', 'success');
    }, 1200);
  };

  const handleDownloadSitemap = () => {
    const blob = new Blob([sitemapXmlContent], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sitemap.xml';
    a.click();
    showToast('sitemap.xml generado y descargado con éxito', 'success');
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-white text-slate-900 text-xs font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
              Módulo 6.1 & 6.2
            </span>
            <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-600" />
              Gestor de Dominios, Cloudflare & Auditoría SEO
            </h1>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Configuración de DNS con Cloudflare Proxy, certificados SSL automáticos, auditoría de indexabilidad On-Page y generación de sitemap.xml.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 shadow-xs">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            <span className="text-[11px] text-emerald-800 font-bold">SSL Activo (Let's Encrypt / Cloudflare)</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('dns')}
          className={`px-3.5 py-1.5 rounded-xl font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
            activeTab === 'dns'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>Registros DNS & Nameservers</span>
        </button>

        <button
          onClick={() => setActiveTab('ssl')}
          className={`px-3.5 py-1.5 rounded-xl font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
            activeTab === 'ssl'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Cloud className="w-3.5 h-3.5" />
          <span>Cloudflare Proxy & Seguridad</span>
        </button>

        <button
          onClick={() => setActiveTab('seo')}
          className={`px-3.5 py-1.5 rounded-xl font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
            activeTab === 'seo'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Search className="w-3.5 h-3.5" />
          <span>Auditoría SEO On-Page</span>
        </button>

        <button
          onClick={() => setActiveTab('sitemap')}
          className={`px-3.5 py-1.5 rounded-xl font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
            activeTab === 'sitemap'
              ? 'bg-blue-600 text-white font-bold shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>Sitemap.xml Dinámico</span>
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'dns' && (
        <div className="space-y-6">
          {/* Domain Picker Bar */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-blue-100 text-blue-600">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500">Dominio Personalizado Vinculado:</span>
                <div className="font-bold text-slate-900 text-sm">{domainName}</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleVerifyDns}
                disabled={isVerifying}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
                <span>Verificar Propagación</span>
              </button>
            </div>
          </div>

          {/* DNS Table */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-xs">Registros DNS Activos</h3>
              <span className="text-[11px] text-slate-500">Zona administrada en Clientum Edge DNS</span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Tipo</th>
                    <th className="p-3">Nombre / Host</th>
                    <th className="p-3">Destino / Valor</th>
                    <th className="p-3">TTL</th>
                    <th className="p-3">Cloudflare Proxy</th>
                    <th className="p-3 text-right">Estado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {records.map((r) => (
                    <tr key={r.id} className="hover:bg-blue-50/40 transition-colors">
                      <td className="p-3 font-bold text-blue-600">{r.type}</td>
                      <td className="p-3 font-mono text-slate-900">{r.host}</td>
                      <td className="p-3 font-mono text-slate-600">{r.value}</td>
                      <td className="p-3 text-slate-500">{r.ttl}</td>
                      <td className="p-3">
                        {r.proxied ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                            Proxied 🟠
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-500">DNS Only ⚪</span>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            r.status === 'Propagado'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'ssl' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-4 shadow-xs">
            <h3 className="font-bold text-slate-900 text-xs flex items-center gap-2">
              <Cloud className="w-4 h-4 text-blue-600" />
              Asistente de Configuración Cloudflare
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Para habilitar protección contra ataques DDoS y aceleración global CDN mediante Cloudflare, asigna los siguientes servidores de nombres en tu registrador (NIC.ar o GoDaddy):
            </p>
            <div className="p-4 rounded-xl bg-white border border-slate-200 font-mono text-xs space-y-2.5 shadow-xs">
              <div className="flex items-center justify-between text-slate-800">
                <span>ns1.clientum-cloudflare.com</span>
                <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">Activo</span>
              </div>
              <div className="flex items-center justify-between text-slate-800">
                <span>ns2.clientum-cloudflare.com</span>
                <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">Activo</span>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-4 shadow-xs">
            <h3 className="font-bold text-slate-900 text-xs flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-600" />
              Certificado SSL & Encriptación
            </h3>
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between text-slate-700 p-2.5 rounded-xl bg-white border border-slate-200">
                <span>Modo de Cifrado</span>
                <span className="font-bold text-emerald-700">Full (Strict) TLS 1.3</span>
              </div>
              <div className="flex items-center justify-between text-slate-700 p-2.5 rounded-xl bg-white border border-slate-200">
                <span>Renovación Automática</span>
                <span className="text-slate-600">Cada 90 días (Automatizada)</span>
              </div>
              <div className="flex items-center justify-between text-slate-700 p-2.5 rounded-xl bg-white border border-slate-200">
                <span>Redirección HTTPS Siempre</span>
                <span className="text-emerald-700 font-bold">Habilitada</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'seo' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Puntaje Global On-Page</span>
              <div className="text-3xl font-extrabold text-emerald-600 flex items-center gap-2 mt-1">
                <span>{seoScore} / 100</span>
                <span className="text-xs px-3 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
                  Excelente Indexabilidad
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={seoTargetUrl}
                onChange={(e) => setSeoTargetUrl(e.target.value)}
                className="bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 shadow-xs focus:outline-none focus:border-blue-600"
              />
              <button
                onClick={() => showToast('Auditoría SEO actualizada con éxito', 'success')}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold cursor-pointer shadow-xs"
              >
                Re-auditar
              </button>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 shadow-xs">
            <h3 className="font-bold text-slate-900 text-xs">Diagnóstico On-Page</h3>
            <div className="space-y-2">
              {seoReport.map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-white border border-slate-200 flex items-center justify-between gap-4 shadow-xs">
                  <div className="space-y-0.5">
                    <span className="font-bold text-slate-900 text-xs">{item.tag}</span>
                    <p className="text-[11px] text-slate-600">{item.text}</p>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 shrink-0">
                    Aprobado ✅
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'sitemap' && (
        <div className="space-y-4">
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between shadow-xs">
            <div>
              <h3 className="font-bold text-slate-900 text-xs">Sitemap XML Dinámico</h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Generado automáticamente a partir de tus páginas de aterrizaje por industria y catálogo digital.
              </p>
            </div>

            <button
              onClick={handleDownloadSitemap}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Descargar sitemap.xml</span>
            </button>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 font-mono text-[11px] text-slate-800 overflow-x-auto whitespace-pre leading-relaxed shadow-xs">
            {sitemapXmlContent}
          </div>
        </div>
      )}
    </div>
  );
};
