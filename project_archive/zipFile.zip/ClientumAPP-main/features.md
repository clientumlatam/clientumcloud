# ClientumCRM - Enterprise Features & Architecture

ClientumCRM is a modern, high-performance enterprise CRM and Power Suite platform designed for sales acceleration, AI-driven automation, omnichannel communication, and operations management.

---

## 1. Comercial & Pipeline CRM
- **Kanban Pipeline Board**: Visual drag-and-drop deal tracking across custom sales stages (Lead, Discovery, Proposal, Negotiation, Won, Lost), weighted probabilities, and revenue metrics.
- **Table View**: Spreadsheet-grade grid view for bulk editing, sorting, and filtering opportunities.
- **Company & People Directories**: Unified Rolodex for managing B2B accounts and key contacts, complete with interaction timelines and associated deals.
- **Task & Activity Management**: Granular task assignment, priority flags (Low, Medium, High, Critical), due dates, and status filters.
- **Analytics & BI Dashboard**: Comprehensive revenue analytics, win/loss conversion ratios, sales velocity charts, and forecast reports powered by Recharts.
- **Maps Prospecting**: Location-based lead discovery and territory mapping.
- **MEDDIC Lead Scoring**: Enterprise qualification framework scoring deals across Metrics, Economic Buyer, Decision Criteria, Decision Process, Identify Pain, and Champion.

---

## 2. Omnichannel & Communication (WhatsApp & Gmail)
- **WhatsApp CRM**: Live chat interface with message history, quick replies, media attachments, and contact assignment.
- **24/7 WhatsApp Chatbot Studio**: No-code conversational rule builder for automated customer qualification and support.
- **Campaigns & Broadcast Manager**: Mass messaging, drip sequences, and engagement tracking.
- **Gmail Inbox Integration**: Secure Google OAuth authentication with real-time inbox message fetching, conversation viewing, and direct email dispatch from within the CRM.

---

## 3. Core Builders & Studio Engines
- **Custom Objects Studio**: Define custom data models, schemas, and fields to tailor the CRM to any industry.
- **Workflows & Flowchart Builder**: Visual automation builder to trigger actions based on deal updates, task creation, or lead scoring thresholds.
- **CSV Import & Export Studio**: Robust CSV data ingestion powered by PapaParse with header validation, live preview, and batch record creation for seamless data migration (e.g., directory lists).

---

## 4. AI Sales Intelligence (Gemini AI)
- **Gemini AI Copilot**: Context-aware assistant for deal summarization, next-step recommendations, and conversational querying.
- **Go-To-Market (GTM) Strategy Generator**: AI-powered market positioning and launch strategy planner.
- **SDR Outreach Agent**: Autonomous outbound prospecting sequence generator.
- **AI Ad Copy Studio**: High-converting advertising copy generator for social and search channels.

---

## 5. ERP, Commerce & Operations
- **ERP & Facturación AFIP**: Electronic invoicing management and tax compliance simulation.
- **MercadoPago Integration**: Payment link generation and transaction tracking.
- **Client Portal**: Self-service customer portal for invoice viewing, support tickets, and order tracking.
- **Restaurant & KDS**: Kitchen Display System and restaurant order management.
- **E-commerce Orders**: Online store order fulfillment and product catalog tracking.

---

## 6. Marketing, Themes & System Settings
- **SEO Suite**: Technical website audit tools and keyword tracking.
- **Web Development & Widgets**: Embeddable lead capture widgets and landing page builder.
- **Theme Engine**: Dynamic switching between **Clientum Obsidian (Dark Mode)** and **Clientum Clarity (High-Contrast Light Mode)** with full accessibility and custom surface styling.
- **Role & Profile Management**: Secure user authentication via Firebase Auth and granular workspace settings.
